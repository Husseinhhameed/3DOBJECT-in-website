![full-design](https://user-images.githubusercontent.com/61243338/111801872-6abfbd00-88de-11eb-8ead-f5166dca4713.png)
# Insert 3D-Objects in a webpage using HTML and CSS only

The following is a simple web structure built using HTML and CSS which may allow one to insert a 3D object.
You can freely use it as a template for your project.
